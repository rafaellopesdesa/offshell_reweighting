# Six-workspace likelihood scans

The requested grid is mu = 0, 0.05, ..., 3.00: exactly 61 points per workspace,
including mu=1. q(mu)=2*(profile NLL - continuous global minimum NLL).
All six current fully normalized workspaces are used read-only. Constrained
NPs and all three free qqZZ factors are profiled; pruned constants stay fixed.
The signed 8192 reference weights are retained. No SumW2 correction is used.

Slurm first computes each continuous global minimum from mu=0.6 and 1.4,
then runs six overlapping 11-point profile chunks for each workspace. Native
intensity/likelihood validation and overlap agreement are required before CSV
export. A failed task does not create a validated CSV for that workspace.

Validated downloads appear in csv/: one <workspace>.csv scan, one
<workspace>_profiled_parameters.csv and one <workspace>_bestfit_parameters.csv
per model. After all six finish, all_scans.csv has 366 rows, global_fits.csv
records the baselines, and likelihood_scans_csv.zip bundles the CSV files.
Completion is confirmed by completion.json. configuration.json and jobs.json
record exact input/source checksums, the grid, resources and Slurm job IDs.

Scan CSV columns include mu, q, profile/global NLL, mu_hat, fit status, EDM,
minimizer wall/CPU seconds, process peak RSS, likelihood calls, independent
Delta-NLL agreement and minimum intensity. RSS is the process high-water mark
through that point within a chunk, not additional memory for that single mu.
Tiny negative q at the generating point can reflect minimizer precision;
values are preserved, not clipped or shifted to a sampled grid minimum.
